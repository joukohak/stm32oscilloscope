/*
 * Copyright (C) 2013 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package fi.jouko.bleoscilloscope;


import java.text.BreakIterator;
import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;
import java.lang.Double;


import android.app.Activity;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattService;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ExpandableListView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.Spinner;
import android.widget.SeekBar;
import android.widget.ArrayAdapter;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;

import static fi.jouko.bleoscilloscope.BluetoothLeService.EXTRA_BYTES;

import android.os.Bundle;

import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.LegendRenderer;
import com.jjoe64.graphview.Viewport;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;




/**
 * For a given BLE device, this Activity provides the user interface to connect, display data,
 * and display GATT services and characteristics supported by the device.  The Activity
 * communicates with {@code BluetoothLeService}, which in turn interacts with the
 * Bluetooth LE API.
 */
public class DeviceControlActivity extends Activity {
    private final static String TAG = DeviceControlActivity.class.getSimpleName();

    public static final String EXTRAS_DEVICE_NAME = "DEVICE_NAME";
    public static final String EXTRAS_DEVICE_ADDRESS = "DEVICE_ADDRESS";



    private TextView mConnectionState;
    private TextView mDataField;
    private TextView mSampleRate;

    private TextView mVMax;
    private TextView mVMin;

    private TextView mTriggerV;


    private String mDeviceName;
    private String mDeviceAddress;
    private ExpandableListView mGattServicesList;
    private BluetoothLeService mBluetoothLeService;
    private ArrayList<ArrayList<BluetoothGattCharacteristic>> mGattCharacteristics =
            new ArrayList<ArrayList<BluetoothGattCharacteristic>>();
    private boolean mConnected = false;
    private BluetoothGattCharacteristic mNotifyCharacteristic;
    private LineGraphSeries<DataPoint> series;
    private LineGraphSeries<DataPoint> series1;
    private int lastX = 0;
    private int period_set=0;

    boolean connect_status_bit=false;
    
    private final String LIST_NAME = "NAME";
    private final String LIST_UUID = "UUID";

    private Handler mHandler;

    // Stops scanning after 10 seconds.
    private static final long SCAN_PERIOD = 10000;
    private byte[] buf_bytes;
    private byte mode = (byte)0x81;

    private int trigger_level=2048;
    private int dcoffset=0;

    private int vmaxi=0;
    private int vmini=0;
    private int i = 0;
    private int TIME = 1000;

    ImageButton auto;
    ImageButton single;
    ImageButton trigger;

    ImageButton edge;
    ImageButton acdc;
    ImageButton sine;

    // Code to manage Service lifecycle.
    private final ServiceConnection mServiceConnection = new ServiceConnection() {

        @Override
        public void onServiceConnected(ComponentName componentName, IBinder service) {
            mBluetoothLeService = ((BluetoothLeService.LocalBinder) service).getService();
            if (!mBluetoothLeService.initialize()) {
                Log.e(TAG, "Unable to initialize Bluetooth");
                finish();
            }
            // Automatically connects to the device upon successful start-up initialization.
            mBluetoothLeService.connect(mDeviceAddress);
        }

        @Override
        public void onServiceDisconnected(ComponentName componentName) {
            mBluetoothLeService = null;
        }
    };

    // Handles various events fired by the Service.
    // ACTION_GATT_CONNECTED: connected to a GATT server.
    // ACTION_GATT_DISCONNECTED: disconnected from a GATT server.
    // ACTION_GATT_SERVICES_DISCOVERED: discovered GATT services.
    // ACTION_DATA_AVAILABLE: received data from the device.  This can be a result of read
    //                        or notification operations.
    private final BroadcastReceiver mGattUpdateReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            final String action = intent.getAction();
            if (BluetoothLeService.ACTION_GATT_CONNECTED.equals(action)) {
                mConnected = true;
                
                
                connect_status_bit=true;
                
                invalidateOptionsMenu();
            } else if (BluetoothLeService.ACTION_GATT_DISCONNECTED.equals(action)) {
                mConnected = false;
                
                updateConnectionState(R.string.disconnected);
                connect_status_bit=false;
                show_view(false);
                invalidateOptionsMenu();
               // clearUI();
            } else if (BluetoothLeService.ACTION_GATT_SERVICES_DISCOVERED.equals(action)) {
                // Show all the supported services and characteristics on the user interface.
                displayGattServices(mBluetoothLeService.getSupportedGattServices());
            } else if (BluetoothLeService.ACTION_DATA_AVAILABLE.equals(action)) {
                //displayData(intent.getStringExtra(BluetoothLeService.EXTRA_DATA));
                displayData(intent.getByteArrayExtra(BluetoothLeService.EXTRA_BYTES));
            }
        }
    };

    // If a given GATT characteristic is selected, check for supported features.  This sample
    // demonstrates 'Read' and 'Notify' features.  See
    // http://d.android.com/reference/android/bluetooth/BluetoothGatt.html for the complete
    // list of supported characteristic features.
    private final ExpandableListView.OnChildClickListener servicesListClickListner =
            new ExpandableListView.OnChildClickListener() {
                @Override
                public boolean onChildClick(ExpandableListView parent, View v, int groupPosition,
                                            int childPosition, long id) {
                	
//                	Log.i("tag", "uu");
//                    if (mGattCharacteristics != null) {
//                        final BluetoothGattCharacteristic characteristic =
//                                mGattCharacteristics.get(groupPosition).get(childPosition);
//                        final int charaProp = characteristic.getProperties();
//                        if ((charaProp | BluetoothGattCharacteristic.PROPERTY_READ) > 0) {
//                            // If there is an active notification on a characteristic, clear
//                            // it first so it doesn't update the data field on the user interface.
//                            if (mNotifyCharacteristic != null) {
//                                mBluetoothLeService.setCharacteristicNotification(
//                                        mNotifyCharacteristic, false);
//                                mNotifyCharacteristic = null;
//                            }
//                            mBluetoothLeService.readCharacteristic(characteristic);
//                        }
//                        if ((charaProp | BluetoothGattCharacteristic.PROPERTY_NOTIFY) > 0) {
//                            mNotifyCharacteristic = characteristic;
//                            mBluetoothLeService.setCharacteristicNotification(
//                                    characteristic, true);
//                        }
//                        return true;
//                    }
                    return false;
                }
    };

    private void clearUI() {
        //mGattServicesList.setAdapter((SimpleExpandableListAdapter) null);
        mDataField.setText(R.string.no_data);
    }



    


    
    boolean pass_en=false;

    boolean auto_trace = false;
    boolean rising_edge = true;
    boolean sinew = false;
    boolean acinput = false;
    



    Timer timer = new Timer();  


    
    String dme ="";
    
    void show_view( boolean p )
    {
    	if(p){
    //		send_button.setEnabled(true);
    	}else{
    //		send_button.setEnabled(false);
    	}
    }
    
    public void delay(int ms){
		try {
            Thread.currentThread();
			Thread.sleep(ms);
        } catch (InterruptedException e) {
            e.printStackTrace();
        } 
	 }	
    
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.gatt_services_characteristics);
        
        final Intent intent = getIntent();
        mDeviceName = intent.getStringExtra(EXTRAS_DEVICE_NAME);
        mDeviceAddress = intent.getStringExtra(EXTRAS_DEVICE_ADDRESS);

        // Sets up UI references.
     //   ((TextView) findViewById(R.id.device_address)).setText(mDeviceAddress);

        mConnectionState = (TextView) findViewById(R.id.connection_state);

 //       mSampleRate = (TextView) findViewById(R.id.sample_rate);
        mVMax = (TextView) findViewById(R.id.batmax_volt);
        mVMin = (TextView) findViewById(R.id.batmin_volt);

        mTriggerV = (TextView) findViewById(R.id.trigger_volt);

        auto=(ImageButton)findViewById(R.id.imageButton1);
        edge=(ImageButton)findViewById(R.id.imageButton2);
        single=(ImageButton)findViewById(R.id.imageButton3);
        acdc=(ImageButton)findViewById(R.id.imageButton4);
        sine=(ImageButton)findViewById(R.id.imageButton5);
        trigger=(ImageButton)findViewById(R.id.imageButton6);

        auto.setOnClickListener(listener);
        single.setOnClickListener(listener);
        edge.setOnClickListener(listener);
        trigger.setOnClickListener(listener);
        acdc.setOnClickListener(listener);
        sine.setOnClickListener(listener);

        edge.setImageDrawable(getResources().getDrawable(R.drawable.rising));
        auto.setEnabled(true);
        single.setEnabled(true);
        edge.setEnabled(true);
        trigger.setEnabled(true);
        acdc.setEnabled(true);
        sine.setEnabled(true);

        GraphView graph = (GraphView) findViewById(R.id.graph);
        graph.setTitle("Digital Oscilloscope");
        series = new LineGraphSeries<DataPoint>();
        series.setDataPointsRadius(10);
        series.setThickness(2);
        series.setTitle("CH1");
        graph.addSeries(series);


        series1 = new LineGraphSeries<DataPoint>();
        series1.setTitle("CH2");
        series1.setColor(Color.RED);
        series1.setThickness(2);
        graph.addSeries(series1);



        // activate horizontal scrolling
        graph.getViewport().setScrollable(true);
        // set manual X bounds
        graph.getViewport().setXAxisBoundsManual(true);
        graph.getViewport().setMinX(0);
        graph.getViewport().setMaxX(500);
        // enable scaling and scrolling
        graph.getViewport().setScalable(true);
        graph.getViewport().setScalableY(true);


        graph.getLegendRenderer().setVisible(true);
        graph.getLegendRenderer().setAlign(LegendRenderer.LegendAlign.TOP);

        graph.getGridLabelRenderer().setNumHorizontalLabels(10);
        graph.getGridLabelRenderer().setHorizontalLabelsVisible(false);
        graph.getGridLabelRenderer().setNumVerticalLabels(10);
        graph.getGridLabelRenderer().setLabelVerticalWidth(64);

        Spinner spinner = (Spinner) findViewById(R.id.spinner);
 //       spinner.setOnItemSelectedListener(this);
// Create an ArrayAdapter using the string array and a default spinner layout
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.sample_period, android.R.layout.simple_spinner_item);
// Specify the layout to use when the list of choices appears
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
// Apply the adapter to the spinner
        spinner.setAdapter(adapter);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
                period_set = parent.getSelectedItemPosition();

            }
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

        SeekBar mseekBar = (SeekBar) findViewById(R.id.mseekBar);

        mseekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {


            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                trigger_level = progress * 4095 / 100;
                float v_trigger = (float)((trigger_level - dcoffset * 2048)* 14.3 / 4096);
                mTriggerV.setText(String.format("%.2f", v_trigger) + " V");
            }

            public void onStartTrackingTouch(SeekBar seekBar) {
                // TODO Auto-generated method stub
            }

            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });



//        show_view(false);
        mHandler = new Handler();
        
        timer.schedule(task, 1000, 1000);  // 1s after the implementation of the task, after 1s again
        
        boolean sg;
 //       getActionBar().setTitle(mDeviceName);
 //       getActionBar().setDisplayHomeAsUpEnabled(true);
        Intent gattServiceIntent = new Intent(this, BluetoothLeService.class);
        sg = bindService(gattServiceIntent, mServiceConnection, BIND_AUTO_CREATE);
      //  getActionBar().setTitle( "="+BluetoothLeService );
      //  mDataField.setText("="+sg );
        updateConnectionState(R.string.connecting);
    }

 /*   @Override
    public void onItemSelected(AdapterView<?> parent, View view,
                               int pos, long id) {
        // An item was selected. You can retrieve the selected item using
        int spinner_pos = parent.getSelectedItemPosition();
        byte speriod = (byte) ((spinner_pos & 0x0007) | 0x00e0);
        String spr = String.format("%02x", speriod);
        mBluetoothLeService.txxx(spr);
    }

    public void onNothingSelected(AdapterView<?> parent) {
        // Another interface callback
    }*/
 private class MyHandler extends Handler {
     public void handleMessage(Message msg) {
         if (msg.what == 1) {

             if (mBluetoothLeService != null) {
                 if( connect_status_bit==false )
                 {
                     final boolean result = mBluetoothLeService.connect(mDeviceAddress);
                     Log.d(TAG, "Connect request result=" + result);
                 }
             }
         }
         super.handleMessage(msg);
     };
 }
    MyHandler handler=new MyHandler();


    TimerTask task = new TimerTask() {

        @Override
        public void run() {
            // Things to do: send a message:
            Message message = new Message();
            message.what = 1;
            handler.sendMessage(message);
        }
    };


    

    
    Button.OnClickListener listener = new Button.OnClickListener(){ //Create a listening object    
        public void onClick(View v){    
            //String strTmp="Click Button02";    
            //Ev1.setText(strTmp);   
        	switch( v.getId())
        	{

                case R.id.imageButton1:
                {
                    if (!auto_trace){
                        auto_trace=true;
                        mode |= 0x80;
                        mode &= 0xEF;
                        sendStartCommand();

                    } else {
                        auto_trace=false;
                    }

                }
                break;

                case R.id.imageButton2:
                {
                    if (rising_edge){
                        edge.setImageDrawable(getResources().getDrawable(R.drawable.falling));
                        rising_edge = false;
                        mode &= 0xbf;
                    } else {
                        edge.setImageDrawable(getResources().getDrawable(R.drawable.rising));
                        rising_edge = true;
                        mode |= 0x40;
                    }
                }
                break;


                case R.id.imageButton3 : //single
                {
                    auto_trace=false;
                    mode &= 0xef;
                    sendStartCommand();
                }

                break;

                case R.id.imageButton4 : //AC-DC select
                {
                    if (acinput) {
                        acdc.setImageDrawable(getResources().getDrawable(R.drawable.dcon));
                        acinput = false;
                        mode |= 0x01;
                        dcoffset=0;
                    } else {
                        acdc.setImageDrawable(getResources().getDrawable(R.drawable.acon));
                        acinput = true;
                        mode &= 0xFE;
                        dcoffset=1;
                    }
                }
                    break;

                case R.id.imageButton5 : //sine output
                {
                    if (sinew){
                        sine.setImageDrawable(getResources().getDrawable(R.drawable.sinioff));
                        sinew = false;
                        mode &= 0xFD;
                    } else {
                        sine.setImageDrawable(getResources().getDrawable(R.drawable.sinion));
                        sinew = true;
                        mode |= 0x02;
                    }
                }

                break;

                case R.id.imageButton6 : //trigger single
                {
                    auto_trace=false;
                    mode |= 0x10;      // single trigger rising /falling
                    sendStartCommand();
                    mode &= 0xEF;
                }

                break;


            }
        }    
  
    };



    @Override
    protected void onResume() {
        super.onResume();
        registerReceiver(mGattUpdateReceiver, makeGattUpdateIntentFilter());
        if (mBluetoothLeService != null) {
        	
            final boolean result = mBluetoothLeService.connect(mDeviceAddress);
            Log.d(TAG, "Connect request result=" + result);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        unregisterReceiver(mGattUpdateReceiver);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        unbindService(mServiceConnection);
        mBluetoothLeService = null;
        timer.cancel();
        timer=null;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.gatt_services, menu);
        if (mConnected) {
            menu.findItem(R.id.menu_connect).setVisible(false);
            menu.findItem(R.id.menu_disconnect).setVisible(true);
        } else {
            menu.findItem(R.id.menu_connect).setVisible(true);
            menu.findItem(R.id.menu_disconnect).setVisible(false);
        }
        return true;
    } 
 
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch(item.getItemId()) {
            case R.id.menu_connect:
                mBluetoothLeService.connect(mDeviceAddress);
                return true;
            case R.id.menu_disconnect:
                mBluetoothLeService.disconnect();
                return true;
            case android.R.id.home:
                onBackPressed();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }





    private void updateConnectionState(final int resourceId) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                mConnectionState.setText(resourceId);
            }
        });
    }



    boolean graphrec=false;

    private void displayData( byte[] data1 ) {

        if( data1==null) {
            return;

        }else if ((data1[0] == 0x2B)&&(!graphrec)){
            graphrec =true;
            datacount=0;
            datatoGraph(data1);
            return;

        }else if (graphrec) {
            if (data1[data1.length - 1] == -1) graphrec = false;
            datatoGraph(data1);
            return;
        }



    }

        byte[] graphdata =new byte[2002];
        int datacount=0;


        private void datatoGraph(byte[] data2) {

            for ( int j=0 ; j < data2.length ; j++) {
                if (datacount < 2002) graphdata[datacount++] = data2[j];
            }

            if (( data2[(data2.length)-1]== -1 ) || ((datacount-2)>=2000)){
                DataPoint[] values = new DataPoint[500];
                DataPoint[] values1 = new DataPoint[500];
                int dcoffset = 0;
                if (acinput) dcoffset =1;
                vmaxi = ((graphdata[3] & 0x000f) << 8) | (graphdata[2] & 0x00ff);
                vmini = vmaxi;
                for (i=0; i<500 ; i++) {
                    int v1 = ((graphdata[4 * i+3] & 0x000f) << 8) | (graphdata[4 * i + 2] & 0x00ff);
                    if (v1 > vmaxi)  vmaxi = v1;
                    if (v1 < vmini) vmini = v1;
                    float chan1 = (float) ((((float)v1 -dcoffset * 2048)/ 4096)*14.3);
                    DataPoint v10 = new DataPoint(lastX, chan1);
                    values[i] = v10;

                    int v2 = ((graphdata[4 * i+5] & 0x000f) << 8) | (graphdata[4 * i + 4] & 0x00ff);
                    float chan2 = (float) ((((float)v2 - dcoffset * 2048)/ 4095)*14.3);
                    DataPoint v20 = new DataPoint(lastX, chan2);
                    values1[i] = v20;

                    lastX++;
                }
                series.resetData(values);
                series1.resetData(values1);
                lastX=0;
                datacount=0;
                graphrec =false;
                float v_max = (float) ((((float)vmaxi -dcoffset * 2048)/ 4096)*14.3);
                String str1 = String.format("%.2f",v_max) +" V";
                mVMax.setText(str1);

                float v_min = (float) ((((float)vmini -dcoffset * 2048)/ 4096)*14.3);
                String str2 = String.format("%.2f",v_min) + " V";
                mVMin.setText(str2);
                if (auto_trace==true){
                    sendStartCommand();
                }

            }
        }


// send sampling start to scope
    byte[] scopeframe = new byte[6];
    private void sendStartCommand()
    {
        scopeframe[0]=(byte)0x2b;
        scopeframe[1]=(byte)mode;
        scopeframe[2]=(byte)(period_set & 0x000f);
        scopeframe[3]=(byte)(trigger_level & 0x00ff);
        scopeframe[4]=(byte)((trigger_level & 0xff00) >> 8);
        scopeframe[5]=(byte)0x23;

        mBluetoothLeService.byteswrite(scopeframe);
    }

        // Demonstrates how to iterate through the supported GATT Services/Characteristics.
    // In this sample, we populate the data structure that is bound to the ExpandableListView
    // on the UI.
    private void displayGattServices(List<BluetoothGattService> gattServices) {
        if (gattServices == null) return;

        if( gattServices.size()>0&&mBluetoothLeService.get_connected_status( gattServices )>=4 )
        {
	        if( connect_status_bit )
			  {
	        	mConnected = true;
	        	
//	            start_sampling.setEnabled(true);
                trigger.setEnabled(true);

	        	show_view( true );
				mBluetoothLeService.enable_JDY_ble(true,0); //Transparent uart service
				 try {  
			            Thread.currentThread();  
			            Thread.sleep(100);  
			        } catch (InterruptedException e) {  
			            e.printStackTrace();  
			        }
	//			 mBluetoothLeService.txxx( "d9" ); //TX data
				 updateConnectionState(R.string.connected);
			  }else{
				  //Toast.makeText(this, "Deleted Successfully!", Toast.LENGTH_LONG).show(); 
				  //Toast toast = Toast.makeText(DeviceControlActivity.this, "Equipment is not connected!", Toast.LENGTH_SHORT); 
				  //toast.show(); 
			  }
        }
        
        
//        SimpleExpandableListAdapter gattServiceAdapter = new SimpleExpandableListAdapter(
//                this,
//                gattServiceData,
//                android.R.layout.simple_expandable_list_item_2,
//                new String[] {LIST_NAME, LIST_UUID},
//                new int[] { android.R.id.text1, android.R.id.text2 },
//                gattCharacteristicData,
//                android.R.layout.simple_expandable_list_item_2,
//                new String[] {LIST_NAME, LIST_UUID},
//                new int[] { android.R.id.text1, android.R.id.text2 }
//        );
//        
//        mGattServicesList.setAdapter(gattServiceAdapter);
        
    }
 
    private static IntentFilter makeGattUpdateIntentFilter() {
        final IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(BluetoothLeService.ACTION_GATT_CONNECTED);
        intentFilter.addAction(BluetoothLeService.ACTION_GATT_DISCONNECTED);
        intentFilter.addAction(BluetoothLeService.ACTION_GATT_SERVICES_DISCOVERED);
        intentFilter.addAction(BluetoothLeService.ACTION_DATA_AVAILABLE);
        intentFilter.addAction(BluetoothLeService.EXTRA_DATA);
        intentFilter.addAction(BluetoothLeService.EXTRA_BYTES);

        return intentFilter;
    }



}

